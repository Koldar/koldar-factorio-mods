-- a string erpresneting how difficult is the particular scenario
DifficultyEnum {
    EASY = "Easy",
    NORMAL = "Normal",
    HARD = "Hard",
    VERY_HRD = "Very Hard",
    EXTREME = "Extreme"
}
