exports = {}

EntityEnum = {
    CHEMICAL_PLANT = "chemical-plant",
}